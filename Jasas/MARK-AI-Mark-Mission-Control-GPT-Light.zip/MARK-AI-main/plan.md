# Mark — Mission Control integration plan

## Цель
Сохранить существующий frontend Mark и добавить реальный backend-контур для 13 функций. Не выдавать локальные расчёты за live-аналитику и не имитировать подключение каналов/конкурентов без источника.

## Архитектура
- `server.js` — статическая раздача + JSON API `/api/mission/*`.
- `mission-backend.js` — доменные actions, валидация, прозрачные локальные расчёты и JSON persistence.
- `data/mission-db.json` — персистентное состояние локального backend; в production заменить на SQL/managed database.
- `app.js` — новый экран Mission Control, API client и UI actions поверх существующего store.
- `styles.css` — премиальный Apple/Linear visual system для Mission Control.

## Статусы
Локально реально работают: Autopilot task orchestration, Campaign drafts, Simulator, Brand Memory, Reputation analysis по переданному тексту, Calendar recommendations, Content scoring, Morning Brief из сохранённых данных, Lead scoring и Specialist tasks.

Competitor Radar и Opportunity Hunter остаются blocked до подключения URL/import/provider. Реальные Telegram/VK/MAX публикации, live reach/ER, bot webhooks и production AI model требуют provider credentials и worker/SQL deployment; UI должен показывать это явно.
