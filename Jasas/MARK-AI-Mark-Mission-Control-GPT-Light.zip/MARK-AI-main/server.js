const http = require('http');
const fs = require('fs');
const path = require('path');
const { handleMission } = require('./mission-backend');

const PORT = process.env.PORT || 3000;
const PUBLIC_DIR = __dirname;
const MIME_TYPES = {
  '.html': 'text/html; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.js': 'application/javascript; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.svg': 'image/svg+xml',
  '.webp': 'image/webp'
};

function sendJson(res, status, value) {
  res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' });
  res.end(JSON.stringify(value));
}
function parseBody(req, callback) {
  let raw = '';
  req.on('data', chunk => { raw += chunk; if (raw.length > 1_000_000) req.destroy(); });
  req.on('end', () => {
    if (!raw) return callback({});
    try { callback(JSON.parse(raw)); } catch { callback(null); }
  });
}
function serveStatic(req, res) {
  let reqPath;
  try { reqPath = decodeURIComponent(req.url.split('?')[0]); } catch { sendJson(res, 400, { ok: false, error: 'Invalid URL' }); return; }
  if (reqPath === '/' || reqPath === '') reqPath = '/index.html';
  const filePath = path.resolve(PUBLIC_DIR, `.${reqPath}`);
  if (!filePath.startsWith(`${PUBLIC_DIR}${path.sep}`)) { sendJson(res, 403, { ok: false, error: 'Forbidden' }); return; }
  fs.stat(filePath, (err, stats) => {
    if (err || !stats.isFile()) { res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' }); res.end('404 Not Found'); return; }
    const ext = path.extname(filePath).toLowerCase();
    res.writeHead(200, { 'Content-Type': MIME_TYPES[ext] || 'application/octet-stream', 'Cache-Control': ext === '.html' ? 'no-cache' : 'public, max-age=3600' });
    fs.createReadStream(filePath).pipe(res);
  });
}

const server = http.createServer((req, res) => {
  const url = req.url.split('?')[0];
  if (url.startsWith('/api/mission/')) {
    if (req.method === 'GET') return handleMission(req, res, url, {});
    if (req.method === 'POST') return parseBody(req, body => body === null ? sendJson(res, 400, { ok: false, error: 'Invalid JSON' }) : handleMission(req, res, url, body));
    return sendJson(res, 405, { ok: false, error: 'Method not allowed' });
  }
  if (url === '/api/health') return sendJson(res, 200, { ok: true, service: 'mark-backend', time: new Date().toISOString() });
  serveStatic(req, res);
});

server.listen(PORT, '0.0.0.0', () => console.log(`Mark frontend + backend running at http://localhost:${PORT}`));
