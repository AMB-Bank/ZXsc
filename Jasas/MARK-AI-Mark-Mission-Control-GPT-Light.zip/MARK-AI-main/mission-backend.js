const fs = require('fs');
const path = require('path');

const DATA_DIR = path.join(__dirname, 'data');
const DB_FILE = path.join(DATA_DIR, 'mission-db.json');

const FEATURE_DEFS = [
  { id: 'autopilot', title: 'AI Autopilot', mode: 'local', description: 'Запускает управляемый цикл задач и фиксирует результат в backend.' },
  { id: 'competitor_radar', title: 'Competitor Radar', mode: 'blocked', description: 'Нужны URL, импорт или API-источник данных конкурентов.' },
  { id: 'campaign_generator', title: 'Campaign Generator', mode: 'local', description: 'Создаёт сохранённый черновик кампании из одного запроса.' },
  { id: 'marketing_simulator', title: 'Marketing Simulator', mode: 'local', description: 'Сравнивает сценарии на основе введённых пользователем предположений.' },
  { id: 'brand_memory', title: 'Brand Memory', mode: 'local', description: 'Хранит факты, тональность и ограничения бренда в backend.' },
  { id: 'reputation_guardian', title: 'Reputation Guardian', mode: 'local', description: 'Проверяет переданный отзыв локальными правилами и сохраняет разбор.' },
  { id: 'smart_calendar', title: 'Smart Calendar', mode: 'local', description: 'Рекомендует свободные слоты на основе сохранённого расписания.' },
  { id: 'content_intelligence', title: 'Content Intelligence', mode: 'local', description: 'Оценивает переданный текст по прозрачным проверяемым правилам.' },
  { id: 'morning_brief', title: 'Morning Brief', mode: 'local', description: 'Собирает отчёт из реально сохранённых задач, кампаний, отзывов и лидов.' },
  { id: 'lead_intelligence', title: 'Lead Intelligence', mode: 'local', description: 'Считает score лида из переданных полей без выдуманных данных.' },
  { id: 'ai_specialist_team', title: 'AI Specialist Team', mode: 'local', description: 'Создаёт маршрутизированную задачу с выбранной ролью специалиста.' },
  { id: 'mission_control', title: 'Mission Control', mode: 'local', description: 'Единый снимок состояния backend-задач и интеграций.' },
  { id: 'opportunity_hunter', title: 'Opportunity Hunter', mode: 'blocked', description: 'Нужен подключённый источник рынка, поиска или аналитики.' }
];

function defaultDb() {
  return {
    version: 1,
    updatedAt: new Date().toISOString(),
    brandMemory: { tone: '', audience: '', promises: [], forbidden: [], facts: [] },
    campaigns: [],
    reviews: [],
    leads: [],
    tasks: [],
    opportunities: [],
    calendar: { slots: [] },
    events: []
  };
}

function loadDb() {
  fs.mkdirSync(DATA_DIR, { recursive: true });
  if (!fs.existsSync(DB_FILE)) {
    const db = defaultDb();
    fs.writeFileSync(DB_FILE, JSON.stringify(db, null, 2));
    return db;
  }
  try { return { ...defaultDb(), ...JSON.parse(fs.readFileSync(DB_FILE, 'utf8')) }; }
  catch { return defaultDb(); }
}

function saveDb(db) {
  db.updatedAt = new Date().toISOString();
  fs.mkdirSync(DATA_DIR, { recursive: true });
  const tmp = `${DB_FILE}.tmp`;
  fs.writeFileSync(tmp, JSON.stringify(db, null, 2));
  fs.renameSync(tmp, DB_FILE);
}

function id(prefix) { return `${prefix}_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 7)}`; }
function text(v, fallback = '') { return typeof v === 'string' ? v.trim() : fallback; }
function num(v, fallback = 0) { const n = Number(v); return Number.isFinite(n) ? n : fallback; }
function iso() { return new Date().toISOString(); }

function contentScore(content) {
  const body = text(content);
  const words = body ? body.split(/\s+/).filter(Boolean) : [];
  const checks = {
    hasContent: body.length > 0,
    minimumLength: body.length >= 80,
    hasCta: /(заказать|узнать|оставить заявку|подробнее|купить|связаться|рассчитать)/i.test(body),
    hasStructure: /[.!?]\s/.test(body) || body.includes('\n'),
    notOverlong: body.length <= 4000
  };
  const passed = Object.values(checks).filter(Boolean).length;
  return { score: Math.round((passed / Object.keys(checks).length) * 100), words: words.length, checks };
}

function reviewAnalysis(body) {
  const value = text(body);
  const negative = /(плохо|ужас|долг|обман|проблем|задерж|дорого|не работает|жалоб)/i.test(value);
  const positive = /(спасибо|отлично|быстро|рекоменд|доволен|качеств|супер)/i.test(value);
  const sentiment = negative ? 'negative' : positive ? 'positive' : 'neutral';
  const priority = negative ? 'high' : sentiment === 'neutral' ? 'medium' : 'low';
  return { sentiment, priority, needsReply: negative || sentiment === 'neutral', matchedRules: [negative && 'negative-language', positive && 'positive-language'].filter(Boolean) };
}

function leadScore(input) {
  const budget = num(input.budget);
  const urgency = num(input.urgency);
  const fit = num(input.fit);
  const contact = text(input.contact);
  const score = Math.max(0, Math.min(100, Math.round((Math.min(budget, 100) * .35) + (Math.min(urgency, 100) * .25) + (Math.min(fit, 100) * .3) + (contact ? 10 : 0))));
  return { score, tier: score >= 75 ? 'hot' : score >= 45 ? 'warm' : 'cold', inputs: { budget, urgency, fit, hasContact: Boolean(contact) } };
}

function simulator(input) {
  const budget = Math.max(0, num(input.budget));
  const ctr = Math.max(0, num(input.ctr, 1)) / 100;
  const cvr = Math.max(0, num(input.cvr, 2)) / 100;
  const reach = Math.round(Math.max(0, num(input.reach, 10000)));
  const clicks = Math.round(reach * ctr);
  const leads = Math.round(clicks * cvr);
  return { assumptions: { budget, ctr: ctr * 100, cvr: cvr * 100, reach }, clicks, leads, costPerLead: leads ? Math.round((budget / leads) * 100) / 100 : null, disclaimer: 'Расчёт основан только на введённых предположениях; live-данные каналов не подключены.' };
}

function snapshot(db) {
  return {
    generatedAt: iso(),
    capabilities: FEATURE_DEFS,
    counts: { campaigns: db.campaigns.length, reviews: db.reviews.length, leads: db.leads.length, tasks: db.tasks.length, opportunities: db.opportunities.length, brandFacts: db.brandMemory.facts.length },
    latest: { task: db.tasks.at(-1) || null, campaign: db.campaigns.at(-1) || null, review: db.reviews.at(-1) || null, lead: db.leads.at(-1) || null },
    brandMemory: db.brandMemory,
    calendar: db.calendar,
    events: db.events.slice(-20)
  };
}

function event(db, type, payload) { db.events.push({ id: id('evt'), type, payload, createdAt: iso() }); if (db.events.length > 200) db.events.shift(); }

function runAction(db, action, payload = {}) {
  const a = text(action);
  if (a === 'mission.snapshot') return { result: snapshot(db) };
  if (a === 'autopilot.run') {
    const task = { id: id('task'), feature: 'autopilot', status: 'queued', title: text(payload.title, 'Проверить контентный контур'), steps: ['проверить расписание', 'проверить черновики', 'проверить заблокированные интеграции'], createdAt: iso() };
    db.tasks.push(task); event(db, 'autopilot.run', task); return { result: task };
  }
  if (a === 'campaign.create') {
    const campaign = { id: id('cmp'), name: text(payload.name, 'Новая кампания'), goal: text(payload.goal, 'Получение заявок'), audience: text(payload.audience, 'Не указана'), status: 'draft', createdAt: iso() };
    db.campaigns.push(campaign); event(db, 'campaign.create', campaign); return { result: campaign };
  }
  if (a === 'simulator.run') { const result = simulator(payload); event(db, 'simulator.run', result); return { result }; }
  if (a === 'brand.save') {
    db.brandMemory = { tone: text(payload.tone), audience: text(payload.audience), promises: Array.isArray(payload.promises) ? payload.promises.map(String).filter(Boolean) : [], forbidden: Array.isArray(payload.forbidden) ? payload.forbidden.map(String).filter(Boolean) : [], facts: Array.isArray(payload.facts) ? payload.facts.map(String).filter(Boolean) : [] };
    event(db, 'brand.save', db.brandMemory); return { result: db.brandMemory };
  }
  if (a === 'reputation.analyze') { const result = { id: id('review'), body: text(payload.body), ...reviewAnalysis(payload.body), createdAt: iso() }; db.reviews.push(result); event(db, 'reputation.analyze', result); return { result }; }
  if (a === 'calendar.recommend') {
    const occupied = new Set((db.calendar.slots || []).map(s => `${s.day}-${s.time}`));
    const candidates = ['Пн-10:00', 'Вт-14:00', 'Ср-11:00', 'Чт-16:00', 'Пт-10:30'].filter(x => !occupied.has(x)).slice(0, 3).map(x => { const [day, time] = x.split('-'); return { day, time, reason: 'Свободный локальный слот' }; });
    const result = { candidates, source: 'saved-calendar-only' }; event(db, 'calendar.recommend', result); return { result };
  }
  if (a === 'content.score') { const result = contentScore(payload.content); event(db, 'content.score', result); return { result }; }
  if (a === 'brief.generate') {
    const result = { title: 'Morning Brief', createdAt: iso(), summary: `Задач: ${db.tasks.length}; кампаний: ${db.campaigns.length}; отзывов: ${db.reviews.length}; лидов: ${db.leads.length}.`, blockers: FEATURE_DEFS.filter(x => x.mode === 'blocked').map(x => x.title) };
    event(db, 'brief.generate', result); return { result };
  }
  if (a === 'lead.score') { const result = { id: id('lead'), ...leadScore(payload), createdAt: iso() }; db.leads.push(result); event(db, 'lead.score', result); return { result }; }
  if (a === 'team.run') {
    const role = text(payload.role, 'Content Specialist');
    const task = { id: id('task'), feature: 'ai_specialist_team', role, status: 'queued', title: text(payload.title, `Задача для ${role}`), createdAt: iso() };
    db.tasks.push(task); event(db, 'team.run', task); return { result: task };
  }
  if (a === 'opportunity.scan' || a === 'competitor.scan') return { blocked: true, code: 'SOURCE_REQUIRED', message: 'Нужен реальный источник данных: URL, импорт или подключённый provider. Данные не выдумываются.' };
  throw Object.assign(new Error(`Unknown mission action: ${a}`), { statusCode: 400 });
}

function handleMission(req, res, url, body) {
  const db = loadDb();
  if (req.method === 'GET' && url === '/api/mission/state') { sendJson(res, 200, { ok: true, ...snapshot(db) }); return; }
  if (req.method === 'POST' && url === '/api/mission/action') {
    try { const out = runAction(db, body && body.action, body && body.payload); if (!out.blocked) saveDb(db); sendJson(res, out.blocked ? 409 : 200, { ok: !out.blocked, ...out, state: snapshot(db) }); }
    catch (e) { sendJson(res, e.statusCode || 500, { ok: false, error: e.message }); }
    return;
  }
  sendJson(res, 404, { ok: false, error: 'Mission endpoint not found' });
}

function sendJson(res, status, value) { res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' }); res.end(JSON.stringify(value)); }

module.exports = { handleMission, DB_FILE, FEATURE_DEFS };
