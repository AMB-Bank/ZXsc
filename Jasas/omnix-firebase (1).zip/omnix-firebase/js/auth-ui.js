import { register, login, reset as sendReset } from './auth.js';
const $ = id => document.getElementById(id);
const EM = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;
const HEAD = { login: ['С возвращением', 'Войдите, чтобы открыть панель OMNIX'], register: ['Создайте аккаунт', 'Это займёт меньше минуты'], reset: ['Восстановление пароля', 'Мы отправим ссылку для создания нового пароля'] };
const PW = [['Не менее 8 символов', v => v.length >= 8], ['Буквы', v => /\p{L}/u.test(v)], ['Цифры', v => /\d/.test(v)]];
const LOGO = '<svg width="30" height="30" viewBox="0 0 40 40" fill="none" stroke="#a9b2c0" stroke-width="1.6"><ellipse cx="20" cy="20" rx="18" ry="7"/><ellipse cx="20" cy="20" rx="18" ry="7" transform="rotate(60 20 20)"/><ellipse cx="20" cy="20" rx="18" ry="7" transform="rotate(120 20 20)"/><circle cx="20" cy="20" r="5" fill="#3aa0ff" stroke="none"/></svg>';
const fld = (id, label, type, ac, pw) => `<div class="f"><label for="${id}">${label}</label><div class="in${pw ? ' pw' : ''}"><input id="${id}" type="${type}" autocomplete="${ac}" spellcheck="false">${pw ? `<button type="button" class="eye" data-eye="${id}">Показать</button>` : ''}</div><small class="fe"></small></div>`;
const btn = t => `<button class="go" type="submit"><span class="lb">${t}</span><span class="spin"></span></button>`;
const TPL = `<div class="auth"><div class="glass" data-mode="login">
<div class="brand">${LOGO}<span>OMNIX</span></div><h1 id="a-t"></h1><p id="a-s"></p>
<div class="seg"><i></i><button type="button" data-m="login">Вход</button><button type="button" data-m="register">Регистрация</button></div>
<div class="stack">
<form class="pn on" data-form="login" novalidate>${fld('l-email', 'Email', 'email', 'email')}${fld('l-pass', 'Пароль', 'password', 'current-password', 1)}
<div class="row2"><label class="chk"><input id="l-rem" type="checkbox" checked><span>Запомнить сессию</span></label><button type="button" class="lnk" data-m="reset">Забыли пароль?</button></div>${btn('Войти')}</form>
<form class="pn" data-form="register" novalidate>${fld('r-name', 'Имя пользователя', 'text', 'name')}${fld('r-email', 'Email', 'email', 'email')}${fld('r-pass', 'Пароль', 'password', 'new-password', 1)}${fld('r-pass2', 'Повторите пароль', 'password', 'new-password', 1)}
<ul class="rq" id="rq">${PW.map(p => `<li>${p[0]}</li>`).join('')}<li>Пароли совпадают</li></ul>
<div class="f"><label class="chk"><input id="r-terms" type="checkbox"><span>Я принимаю условия использования</span></label><small class="fe"></small></div>${btn('Создать аккаунт')}</form>
<form class="pn" data-form="reset" novalidate><div id="p-form">${fld('p-email', 'Email', 'email', 'email')}${btn('Отправить письмо')}</div>
<div id="p-done" hidden><div class="okc">✓</div><p id="p-msg"></p></div><button type="button" class="lnk back" data-m="login">← Вернуться ко входу</button></form>
</div><div class="err" id="a-err" role="alert" aria-live="polite"></div></div></div>`;

let root, box;
export function mountAuth(el) {
  root = el; el.insertAdjacentHTML('beforeend', TPL); box = el.querySelector('.glass');
  el.querySelectorAll('.pn').forEach(p => [...p.children].forEach((c, i) => c.style.setProperty('--i', i)));
  el.addEventListener('click', onClick); el.addEventListener('input', onInput); el.addEventListener('submit', onSubmit);
  go('login', true);
}
export function showAuth() {
  root.querySelectorAll('input').forEach(i => { if (i.type !== 'checkbox') i.value = ''; if (i.dataset.eye) i.type = 'password'; });
  root.querySelectorAll('.eye').forEach(b => b.textContent = 'Показать');
  $('r-terms').checked = false; reqs(); go('login', true);
  root.dataset.state = 'form'; document.body.classList.add('locked');
}
export function hideAuth() { root.dataset.state = 'hidden'; document.body.classList.remove('locked'); }

function go(m, first) {
  box.dataset.mode = m;
  root.querySelectorAll('.pn').forEach(p => p.classList.toggle('on', p.dataset.form === m));
  root.querySelectorAll('.seg button').forEach(b => b.classList.toggle('on', b.dataset.m === m));
  for (const id of ['a-t', 'a-s']) { const e = $(id); e.textContent = HEAD[m][id === 'a-t' ? 0 : 1]; e.classList.remove('sw'); void e.offsetWidth; e.classList.add('sw'); }
  setErr(''); clearFe();
  if (m === 'reset') { $('p-form').hidden = false; $('p-done').hidden = true; if (!$('p-email').value) $('p-email').value = $('l-email').value; }
  if (!first && !matchMedia('(pointer:coarse)').matches) setTimeout(() => root.querySelector('.pn.on input')?.focus(), 320);
}
function onClick(e) {
  const m = e.target.closest('[data-m]'); if (m) return go(m.dataset.m);
  const y = e.target.closest('[data-eye]');
  if (y) { const i = $(y.dataset.eye), s = i.type === 'password'; i.type = s ? 'text' : 'password'; y.textContent = s ? 'Скрыть' : 'Показать'; }
}
function onInput(e) {
  const f = e.target.closest('.f'); if (f) { f.classList.remove('bad'); f.querySelector('.fe').textContent = ''; }
  setErr(''); if (/^r-pass/.test(e.target.id)) reqs();
}
function reqs() {
  const a = $('r-pass').value, b = $('r-pass2').value, li = $('rq').children;
  PW.forEach((p, i) => li[i].classList.toggle('ok', p[1](a))); li[PW.length].classList.toggle('ok', !!b && a === b);
}
const setErr = m => { const e = $('a-err'); if (m) e.textContent = m; e.classList.toggle('on', !!m); };
const setFe = (id, m) => { const f = $(id).closest('.f'); f.classList.add('bad'); f.querySelector('.fe').textContent = m; };
const clearFe = () => root.querySelectorAll('.f').forEach(f => { f.classList.remove('bad'); f.querySelector('.fe').textContent = ''; });

async function onSubmit(e) {
  e.preventDefault();
  const form = e.target, f = form.dataset.form, v = id => $(id).value;
  let bad = false; const fe = (id, m) => { setFe(id, m); bad = true; };
  const mail = id => { const x = v(id).trim(); if (!x) fe(id, 'Введите email'); else if (!EM.test(x)) fe(id, 'Проверьте формат email'); return x; };
  setErr(''); clearFe();
  const b = form.querySelector('.go'); let note = null;
  try {
    if (f === 'login') {
      const em = mail('l-email'); if (!v('l-pass')) fe('l-pass', 'Введите пароль'); if (bad) return;
      b.classList.add('busy'); b.disabled = true; note = await login(em, v('l-pass'), $('l-rem').checked);
    } else if (f === 'register') {
      const nm = v('r-name').trim(), em = mail('r-email'), p = v('r-pass');
      if (nm.length < 2 || nm.length > 40) fe('r-name', 'Имя должно содержать от 2 до 40 символов');
      if (!PW.every(r => r[1](p))) fe('r-pass', 'Пароль не соответствует требованиям');
      if (!v('r-pass2') || p !== v('r-pass2')) fe('r-pass2', 'Пароли не совпадают');
      if (!$('r-terms').checked) fe('r-terms', 'Необходимо принять условия использования');
      if (bad) return;
      b.classList.add('busy'); b.disabled = true; note = await register(nm, em, p);
    } else {
      const em = mail('p-email'); if (bad) return;
      b.classList.add('busy'); b.disabled = true; await sendReset(em);
      $('p-msg').textContent = `Если аккаунт с адресом ${em} существует, мы отправили письмо со ссылкой для сброса пароля. Проверьте также папку «Спам».`;
      $('p-form').hidden = true; $('p-done').hidden = false;
    }
    if (note && !note.profileOk) window.OMNIX?.toast('Вы вошли, но профиль в Firestore не сохранён. Проверьте настройки базы данных.');
  } catch (err) { setErr(err.message); }
  finally { b.classList.remove('busy'); b.disabled = false; }
}
