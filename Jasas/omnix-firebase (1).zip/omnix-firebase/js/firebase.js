// Единственная точка инициализации Firebase. Analytics не подключается.
import { initializeApp, getApps, getApp } from 'https://www.gstatic.com/firebasejs/10.14.1/firebase-app.js';
import { getAuth } from 'https://www.gstatic.com/firebasejs/10.14.1/firebase-auth.js';
import { getFirestore } from 'https://www.gstatic.com/firebasejs/10.14.1/firebase-firestore.js';

export const firebaseConfig = {
  apiKey: "AIzaSyAIpdKZ5Mbab-qpJcqhvMm-0ff1kAEmNc",
  authDomain: "mark-d9e6c.firebaseapp.com",
  projectId: "mark-d9e6c",
  storageBucket: "mark-d9e6c.firebasestorage.app",
  messagingSenderId: "656618859286",
  appId: "1:656618859286:web:9cc4bfae2171383c10be37",
  measurementId: "G-ERJ6JSP1H0"
};

const app = getApps().length ? getApp() : initializeApp(firebaseConfig);
export const auth = getAuth(app);
auth.languageCode = 'ru'; // письма Firebase (сброс пароля) приходят на русском
export const db = getFirestore(app);

// Диагностика конфигурации (ключ API — публичный идентификатор, но в консоль выводится в маске).
const k = firebaseConfig.apiKey;
console.info('[OMNIX Firebase] projectId=%s | authDomain=%s | apiKey=%s…%s | длина=%d (обычно 39) | в getAuth передан тот же ключ: %s',
  auth.app.options.projectId, auth.app.options.authDomain, k.slice(0, 6), k.slice(-4), k.length, auth.app.options.apiKey === k);
