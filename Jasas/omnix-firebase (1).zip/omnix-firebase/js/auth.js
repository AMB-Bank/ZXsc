// Весь код Firebase Authentication/Firestore живёт только здесь. Пароли и токены не логируются.
import { auth, db } from './firebase.js';
import {
  createUserWithEmailAndPassword, signInWithEmailAndPassword, sendPasswordResetEmail,
  signOut, onAuthStateChanged, updateProfile, setPersistence,
  browserLocalPersistence, browserSessionPersistence
} from 'https://www.gstatic.com/firebasejs/10.14.1/firebase-auth.js';
import { doc, getDoc, setDoc, serverTimestamp } from 'https://www.gstatic.com/firebasejs/10.14.1/firebase-firestore.js';

const MSG = {
  'auth/invalid-email': 'Некорректный адрес электронной почты.',
  'auth/missing-email': 'Введите адрес электронной почты.',
  'auth/missing-password': 'Введите пароль.',
  'auth/user-disabled': 'Этот аккаунт заблокирован.',
  'auth/user-not-found': 'Аккаунт с таким адресом не найден.',
  'auth/wrong-password': 'Неверный email или пароль.',
  'auth/invalid-credential': 'Неверный email или пароль.',
  'auth/email-already-in-use': 'Аккаунт с таким email уже существует. Войдите или восстановите пароль.',
  'auth/weak-password': 'Слишком простой пароль. Используйте не менее 8 символов, буквы и цифры.',
  'auth/too-many-requests': 'Слишком много попыток. Подождите несколько минут и повторите.',
  'auth/network-request-failed': 'Нет соединения с сервером. Проверьте интернет и повторите попытку.',
  'auth/operation-not-allowed': 'Вход по email и паролю не включён в консоли Firebase.',
  'auth/invalid-api-key': 'Ключ API не передан или пуст в конфигурации Firebase.',
  'auth/api-key-not-valid.-please-pass-a-valid-api-key.': 'Серверы Firebase не приняли ключ API: он не найден или не принадлежит этому проекту.',
  'auth/unauthorized-domain': 'Этот домен не добавлен в список разрешённых в консоли Firebase.',
  'auth/configuration-not-found': 'Authentication не настроена в проекте Firebase.',
  'auth/internal-error': 'Внутренняя ошибка сервиса. Повторите попытку позже.'
};
export const explain = e => (MSG[e?.code] || 'Не удалось выполнить действие. Повторите попытку.') + ` [код: ${e?.code || 'нет кода'}]`;
const wrap = async fn => {
  try { return await fn(); }
  catch (e) { console.error('[OMNIX Auth] code:', e?.code, '| message:', e?.message); const x = new Error(explain(e)); x.code = e?.code; throw x; }
};

let listener = () => {};
export const watchAuth = cb => { listener = cb; return onAuthStateChanged(auth, cb); };

// Профиль: users/{uid}. Компании в будущем: users/{uid}/companies/{companyId}.
async function ensureProfile(user, name) {
  try {
    const ref = doc(db, 'users', user.uid);
    if (!(await getDoc(ref)).exists()) {
      await setDoc(ref, { uid: user.uid, displayName: name || user.displayName || '', email: user.email, createdAt: serverTimestamp(), companyIds: [] });
    }
    return true;
  } catch (e) { console.error('Профиль не сохранён:', e?.code || 'unknown'); return false; }
}

export const register = (name, email, password) => wrap(async () => {
  await setPersistence(auth, browserLocalPersistence);
  const { user } = await createUserWithEmailAndPassword(auth, email, password);
  await updateProfile(user, { displayName: name });
  const profileOk = await ensureProfile(user, name);
  listener(auth.currentUser); // onAuthStateChanged не срабатывает на updateProfile
  return { profileOk };
});

export const login = (email, password, remember) => wrap(async () => {
  await setPersistence(auth, remember ? browserLocalPersistence : browserSessionPersistence);
  const { user } = await signInWithEmailAndPassword(auth, email, password);
  return { profileOk: await ensureProfile(user) };
});

export const reset = email => wrap(() => sendPasswordResetEmail(auth, email));
export const logout = () => wrap(() => signOut(auth));
