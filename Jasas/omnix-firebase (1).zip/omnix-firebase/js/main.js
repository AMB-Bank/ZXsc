import './firebase.js';
import { watchAuth, logout } from './auth.js';
import { mountAuth, showAuth, hideAuth } from './auth-ui.js';

mountAuth(document.getElementById('auth-root'));
window.OMNIX.logout = async () => {
  try { await logout(); } catch (e) { window.OMNIX.toast(e.message); }
};
watchAuth(user => {
  if (user) { window.OMNIX.setUser(user.displayName || user.email); hideAuth(); }
  else { window.OMNIX.clear(); showAuth(); }
});
